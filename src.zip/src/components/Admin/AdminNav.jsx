import React from "react";
import { Link, useLocation } from "react-router-dom";
import { 
  LayoutDashboard, 
  Users, 
  Bell, 
  Settings,
} from "lucide-react";

const AdminNav = () => {
  const location = useLocation();

  const navItems = [
    {
      label: "Dashboard",
      path: "/admin/dashboard",
      icon: LayoutDashboard,
    },
    {
      label: "Users",
      path: "/admin/users",
      icon: Users,
    },
    {
      label: "Announcements",
      path: "/admin/announcements",
      icon: Bell,
    },
    {
      label: "Settings",
      path: "/admin/settings",
      icon: Settings,
    },
  ];

  const isActive = (path) =>
    location.pathname === path ||
    (path !== "/admin/dashboard" && location.pathname.startsWith(path));

  return (
    <nav className="bg-white dark:bg-gray-700/80 border-b border-gray-200 dark:border-gray-600/50 sticky top-16 z-10">
      <div className="max-w-screen-2xl mx-auto overflow-x-auto scrollbar-none">
        <div className="flex justify-center min-w-max px-2 sm:px-0">
          {navItems.map(({ label, path, icon: Icon }) => (
            <Link
              key={path}
              to={path}
              className={`flex items-center justify-center min-w-[4.5rem] sm:min-w-0 px-2 sm:px-4 py-3 sm:py-4 text-xs sm:text-sm font-medium transition-colors ${
                isActive(path)
                  ? "border-b-2 border-purple-500 text-purple-600 dark:text-purple-400"
                  : "text-gray-500 dark:text-gray-300 hover:text-gray-700 dark:hover:text-gray-100 hover:border-b-2 hover:border-gray-300 dark:hover:border-gray-500"
              }`}
            >
              <Icon
                className="h-5 w-5 sm:h-4 sm:w-4 sm:mr-2"
                aria-hidden="true"
              />
              <span className="hidden sm:inline">{label}</span>
              <span className="sm:hidden text-center" aria-label={label}>
                {label.split(" ")[0]}
              </span>
            </Link>
          ))}
        </div>
      </div>
    </nav>
  );
};

export default AdminNav;