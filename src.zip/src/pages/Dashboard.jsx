// src/pages/Dashboard.jsx
import { useState, useEffect } from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import { Pencil, Trash2, BookOpen, Upload, X } from "lucide-react";
import TradeModal from "../components/TradeModal";
import OptionTradeModal from "../components/OptionTradeModal";
import { useTrades } from "../hooks/useTrades";
import { useOptionTrades } from "../hooks/useOptionsTrades";
import { useAuth } from "../context/AuthContext";
import ReviewModal from "../components/ReviewModal";
import ImportTradeModal from "../components/ImportTradeModal";
import DashboardNav from "../components/DashboardNav";
import { formatInTimeZone } from "date-fns-tz";
import Overview from "../components/Overview";
import TradeJournal from "../components/TradeJournal";
import Analysis from "../components/Analysis";
import Planning from "../components/Planning";
import StatsOverview from "../components/StatsOverview";
import { useToast } from "../context/ToastContext";

const Dashboard = () => {
  const { user, checkSubscriptionStatus, loading: authLoading } = useAuth();
  const userTimeZone = user?.preferences?.timeZone || "UTC";
  const [isTradeModalOpen, setIsTradeModalOpen] = useState(false);
  const [selectedTrade, setSelectedTrade] = useState(null);
  const {
    trades,
    stats,
    loading,
    error,
    addTrade,
    updateTrade,
    deleteTrade,
    fetchTrades,
    fetchTradeStats,
  } = useTrades(user);
  const {
    trades: optionTrades,
    stats: optionStats,
    loading: optionLoading,
    error: optionError,
    fetchTrades: fetchOptionTrades,
    fetchOptionTradeStats,
    deleteOptionTrade,
  } = useOptionTrades();
  const [activeChart, setActiveChart] = useState("pnl");
  const [isReviewModalOpen, setIsReviewModalOpen] = useState(false);
  const [selectedTradeForReview, setSelectedTradeForReview] = useState(null);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [selectedTrades, setSelectedTrades] = useState(new Set());
  const [bulkDeleteError, setBulkDeleteError] = useState(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const { showToast } = useToast();
  const [isOptionTradeModalOpen, setIsOptionTradeModalOpen] = useState(false);
  const [selectedOptionTrade, setSelectedOptionTrade] = useState(null);
  const [dataLoading, setDataLoading] = useState(false);

  useEffect(() => {
    console.log("🚀 Dashboard mounted, user state:", user);
  }, [user]);

  // Prevent fetching if user is null or undefined
  const tradeHooks = user?._id
    ? useTrades(user)
    : { trades: [], stats: {}, loading: true };

  console.log("🟢 Dashboard: useTrades initialized", tradeHooks);

  useEffect(() => {
    if (!user) return;

    let isMounted = true;

    (async () => {
      try {
        setDataLoading(true);

        const [tradeStats, optionTradeStats, stockTrades, optionTrades] =
          await Promise.all([
            fetchTradeStats(),
            fetchOptionTradeStats(),
            fetchTrades(),
            fetchOptionTrades(),
          ]);

        if (!isMounted) return;

        console.log("📊 Trade Stats (Stock):", tradeStats);
        console.log("📊 Option Trade Stats:", optionTradeStats);
        console.log("📈 Loaded Stock Trades:", stockTrades);
        console.log("📈 Loaded Option Trades:", optionTrades);

        const mergedStats = {
          ...tradeStats,
          totalProfit:
            (tradeStats?.totalProfit || 0) +
            (optionTradeStats?.totalProfit || 0),
          totalOptionProfit: optionTradeStats?.totalProfit || 0,
        };

        setStats((prevStats) =>
          JSON.stringify(prevStats) !== JSON.stringify(mergedStats)
            ? mergedStats
            : prevStats
        );
      } catch (err) {
        console.error("❌ Error loading initial data:", err);
      } finally {
        setDataLoading(false);
      }
    })();

    return () => {
      isMounted = false;
    };
  }, [user]);

  useEffect(() => {
    const checkStripeSuccess = async () => {
      const queryParams = new URLSearchParams(window.location.search);
      if (queryParams.get("success") === "true") {
        try {
          await checkSubscriptionStatus();
          showToast("Subscription activated successfully!", "success");
          window.history.replaceState({}, "", "/dashboard");
          setIsLoading(false);
        } catch (error) {
          console.error("Error checking subscription status:", error);
          showToast(
            "Error verifying subscription. Please refresh the page.",
            "error"
          );
          setIsLoading(false);
        }
      } else {
        setIsLoading(false);
      }
    };
    checkStripeSuccess();
  }, [checkSubscriptionStatus, showToast]);

  if (authLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-pulse text-lg">Loading...</div>
      </div>
    );
  }

  const handleAddOptionTradeClick = () => {
    setSelectedOptionTrade(null);
    setIsOptionTradeModalOpen(true);
  };

  const handleOptionTradeSubmit = async (tradeData) => {
    try {
      const cleanedData = {
        ...tradeData,
        strategy: tradeData.strategy || undefined,
        setupType: tradeData.setupType || undefined,
        greeksAtEntry: Object.fromEntries(
          Object.entries(tradeData.greeksAtEntry || {}).filter(
            ([_, v]) => v !== ""
          )
        ),
        greeksAtExit: Object.fromEntries(
          Object.entries(tradeData.greeksAtExit || {}).filter(
            ([_, v]) => v !== ""
          )
        ),
        marketConditions: {
          ...tradeData.marketConditions,
          vix: tradeData.marketConditions.vix || undefined,
        },
      };

      const response = await fetch(
        `${import.meta.env.VITE_API_URL}/api/option-trades`,
        {
          method: selectedOptionTrade ? "PUT" : "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
          body: JSON.stringify(cleanedData),
        }
      );

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Failed to save option trade");
      }

      await fetchOptionTrades(); // Fetch the updated trades
      await fetchOptionTradeStats(); // Fetch the updated stats (Correct function)

      setIsOptionTradeModalOpen(false);
      setSelectedOptionTrade(null);
      showToast("Option trade saved successfully", "success");
    } catch (error) {
      console.error("Error saving option trade:", error);
      showToast(error.message, "error");
    }
  };

  const formatCurrency = (value, maxDecimals = 2) => {
    if (!value && value !== 0) return "-";

    // Convert to string and remove any existing formatting
    const numStr = Math.abs(value).toString();

    // Find the number of actual decimal places
    const decimalPlaces = numStr.includes(".")
      ? numStr.split(".")[1].replace(/0+$/, "").length // Remove trailing zeros
      : 0;

    // Use the smaller of actual decimal places or maxDecimals
    const decimals = Math.min(decimalPlaces, maxDecimals);

    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals,
    }).format(value);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-pulse text-lg">Loading...</div>
      </div>
    );
  }

  const handleReviewSubmit = async (reviewData) => {
    try {
      const response = await fetch(
        `${import.meta.env.VITE_API_URL}/api/trade-reviews`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
          body: JSON.stringify(reviewData),
        }
      );

      if (response.ok) {
        setIsReviewModalOpen(false);
        setSelectedTradeForReview(null);
        // Optionally show a success message
      }
    } catch (error) {
      console.error("Error submitting review:", error);
      // Optionally show an error message
    }
  };

  const handleSubmit = async (tradeData) => {
    let success;
    if (selectedTrade) {
      // If we have a selectedTrade, we're editing
      success = await updateTrade(selectedTrade._id, tradeData);
    } else {
      // Otherwise, we're adding a new trade
      success = await addTrade(tradeData);
    }

    if (success) {
      setIsTradeModalOpen(false);
      setSelectedTrade(null);
    }
  };

  const handleEditClick = (trade) => {
    if (trade.contractType) {
      setSelectedOptionTrade(trade);
      setIsOptionTradeModalOpen(true);
    } else {
      setSelectedTrade(trade);
      setIsTradeModalOpen(true);
    }
  };

  const handleDeleteClick = async (trade) => {
    if (!trade || !trade._id) {
      console.error("❌ Trade or Trade ID is missing!");
      return;
    }

    const isOptionTrade = trade.contractType !== undefined; // Assuming contractType exists in option trades

    if (
      window.confirm(
        `Are you sure you want to delete this ${
          isOptionTrade ? "option" : "regular"
        } trade?`
      )
    ) {
      const success = isOptionTrade
        ? await deleteOptionTrade(trade._id)
        : await deleteTrade(trade._id);

      if (success) {
        console.log(
          `✅ Successfully deleted ${
            isOptionTrade ? "option" : "regular"
          } trade.`
        );
      } else {
        console.error(
          `❌ Failed to delete ${isOptionTrade ? "option" : "regular"} trade.`
        );
      }
    }
  };

  const handleSelectTrade = (tradeId) => {
    const newSelected = new Set(selectedTrades);
    if (newSelected.has(tradeId)) {
      newSelected.delete(tradeId);
    } else {
      newSelected.add(tradeId);
    }
    setSelectedTrades(newSelected);
  };

  const handleSelectAll = (currentTrades) => {
    const areAllSelected = currentTrades.every((trade) =>
      selectedTrades.has(trade._id)
    );

    if (areAllSelected) {
      const newSelected = new Set(selectedTrades);
      currentTrades.forEach((trade) => newSelected.delete(trade._id));
      setSelectedTrades(newSelected);
    } else {
      const newSelected = new Set(selectedTrades);
      currentTrades.forEach((trade) => newSelected.add(trade._id));
      setSelectedTrades(newSelected);
    }
  };

  const handleBulkDelete = async () => {
    if (selectedTrades.size === 0) return;

    if (
      !window.confirm(
        `Are you sure you want to delete ${selectedTrades.size} trades?`
      )
    ) {
      return;
    }

    setIsDeleting(true);
    setBulkDeleteError(null);

    try {
      const response = await fetch(
        `${import.meta.env.VITE_API_URL}/api/trades/bulk-delete`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
          body: JSON.stringify({
            tradeIds: Array.from(selectedTrades),
          }),
        }
      );

      if (!response.ok) {
        throw new Error("Failed to delete trades");
      }

      const [tradeStats, optionStats] = await Promise.all([
        fetchStats(),
        fetchOptionStats(),
      ]);

      useEffect(() => {
        if (authLoading || !user) return;

        (async () => {
          try {
            setDataLoading(true);
            const [tradeStats, optionTradeStats] = await Promise.all([
              fetchTradeStats(),
              fetchOptionTradeStats(),
            ]);

            console.log("📊 Trade Stats (Stock):", tradeStats);
            console.log("📊 Option Trade Stats:", optionTradeStats);

            setStats({
              ...tradeStats, // Ensure stock trade stats stay intact
              totalProfit:
                (tradeStats?.totalProfit || 0) +
                (optionTradeStats?.totalProfit || 0), // ✅ Combine total profits
              totalOptionProfit: optionTradeStats?.totalProfit || 0, // ✅ Explicitly add option P/L
            });
          } catch (err) {
            console.error("❌ Error loading initial data:", err);
          } finally {
            setDataLoading(false);
          }
        })();
      }, [user]);

      // Merge total profits
      const combinedStats = {
        ...tradeStats,
        totalProfit:
          (tradeStats.totalProfit || 0) + (optionStats.totalProfit || 0),
      };

      // Update state
      setStats(combinedStats);
      setSelectedTrades(new Set());
    } catch (err) {
      setBulkDeleteError("Failed to delete trades. Please try again.");
      console.error("Bulk delete error:", err);
    } finally {
      setIsDeleting(false);
    }
  };

  const handleModalClose = () => {
    setIsTradeModalOpen(false);
    setSelectedTrade(null);
  };

  const handleAddTradeClick = () => {
    setSelectedTrade(null);
    setIsTradeModalOpen(true);
  };

  const formatDate = (dateString) => {
    return formatInTimeZone(
      new Date(dateString),
      userTimeZone,
      "MM/dd/yyyy hh:mm a"
    );
  };

  if (error) {
    return (
      <div className="w-full min-h-screen pt-16 px-3 sm:px-6 py-3 sm:py-6 flex items-center justify-center text-red-600 dark:text-red-400">
        <div className="bg-red-50 dark:bg-red-900/30 p-4 rounded-lg">
          Error: {error}
        </div>
      </div>
    );
  }

  const handleImportTrades = async (trades) => {
    const success = await importTrades(trades);
    if (success) {
      setIsImportModalOpen(false);
    }
  };

  return (
    <div className="flex flex-col min-h-screen pt-16">
      {" "}
      {/* Added pt-16 for fixed navbar */}
      <DashboardNav />
      {/* Stats Overview Section */}
      <div className="px-3 sm:px-6 py-3 sm:py-4 bg-transparent">
        <StatsOverview
          user={user}
          stats={stats}
          formatCurrency={formatCurrency}
        />
      </div>
      {/* Main Content */}
      <div className="flex-1">
        <Routes>
          <Route path="" element={<Navigate to="overview" replace />} />
          {[
            {
              path: "overview",
              element: (
                <Overview
                  trades={trades}
                  stats={stats}
                  formatCurrency={formatCurrency}
                />
              ),
            },
            {
              path: "journal",
              element: (
                <TradeJournal
                  trades={[...trades, ...optionTrades]}
                  handleEditClick={handleEditClick}
                  handleDeleteClick={handleDeleteClick}
                  handleSelectTrade={handleSelectTrade}
                  handleSelectAll={handleSelectAll}
                  handleBulkDelete={handleBulkDelete}
                  handleAddTradeClick={handleAddTradeClick}
                  handleAddOptionTradeClick={handleAddOptionTradeClick}
                  selectedTrades={selectedTrades}
                  isDeleting={isDeleting}
                  bulkDeleteError={bulkDeleteError}
                  setBulkDeleteError={setBulkDeleteError}
                  formatDate={formatDate}
                  formatCurrency={formatCurrency}
                  setSelectedTradeForReview={setSelectedTradeForReview}
                  setIsReviewModalOpen={setIsReviewModalOpen}
                />
              ),
            },
            {
              path: "analysis",
              element: (
                <Analysis
                  trades={trades}
                  activeChart={activeChart}
                  setActiveChart={setActiveChart}
                />
              ),
            },
            {
              path: "planning",
              element: <Planning trades={trades} user={user} stats={stats} />,
            },
          ].map(({ path, element }) => (
            <Route
              key={path}
              path={path}
              element={
                <div className="px-3 sm:px-6 py-3 sm:py-4">{element}</div>
              }
            />
          ))}
          <Route path="*" element={<Navigate to="overview" replace />} />
        </Routes>
      </div>
      {/* Modals */}
      <TradeModal
        isOpen={isTradeModalOpen}
        onClose={handleModalClose}
        onSubmit={handleSubmit}
        trade={selectedTrade}
        userTimeZone={userTimeZone}
      />
      <OptionTradeModal
        isOpen={isOptionTradeModalOpen}
        onClose={() => {
          setIsOptionTradeModalOpen(false);
          setSelectedOptionTrade(null);
        }}
        onSubmit={handleOptionTradeSubmit}
        trade={selectedOptionTrade}
        userTimeZone={userTimeZone}
      />
      <ReviewModal
        isOpen={isReviewModalOpen}
        onClose={() => {
          setIsReviewModalOpen(false);
          setSelectedTradeForReview(null);
        }}
        trade={selectedTradeForReview}
        onSubmit={handleReviewSubmit}
      />
      <ImportTradeModal
        isOpen={isImportModalOpen}
        onClose={() => setIsImportModalOpen(false)}
        onImport={handleImportTrades}
      />
      {/* Error Display */}
      {error && (
        <div className="fixed bottom-4 left-4 right-4 p-4 bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400 rounded-lg shadow-lg">
          Error: {error}
        </div>
      )}
    </div>
  );
};

export default Dashboard;
