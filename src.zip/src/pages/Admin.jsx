import React, { useState } from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import AdminNav from "../components/Admin/AdminNav";
import Dashboard from "../components/Admin/Dashboard";
import UserManagement from "../components/Admin/UserManagement";
import Announcements from "../components/Admin/Announcements";
import Settings from "../components/Admin/Settings";

const Admin = () => {
  const { user, loading: authLoading } = useAuth();

  if (authLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-pulse text-lg">Loading...</div>
      </div>
    );
  }

  // Extra check for admin access
  const isAdmin = 
    user?.specialAccess?.hasAccess && 
    user?.specialAccess?.reason === "Admin";
  
  if (!isAdmin) {
    return <Navigate to="/dashboard" replace />;
  }

  return (
    <div className="flex flex-col min-h-screen pt-16">
      {/* Admin Navigation */}
      <AdminNav />

      {/* Admin Header */}
      <div className="px-3 sm:px-6 py-3 sm:py-4 bg-gray-50 dark:bg-gray-700/40">
        <div className="bg-gray-100 dark:bg-gray-700/60 p-3 sm:p-6 rounded-sm border border-gray-200 dark:border-gray-600/50 shadow-sm">
          <h1 className="text-lg sm:text-xl font-bold text-gray-900 dark:text-gray-100">
            Admin Portal
          </h1>
          <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-300 mt-1">
            Manage users, content, and system settings
          </p>
        </div>
      </div>

      {/* Admin Content */}
      <div className="flex-1 w-full px-3 sm:px-6 py-3 sm:py-4 dark:bg-gray-700/30">
        <Routes>
          <Route path="dashboard" element={<Dashboard />} />
          <Route path="users/*" element={<UserManagement />} />
          <Route path="announcements" element={<Announcements />} />
          <Route path="settings" element={<Settings />} />
          <Route path="/" element={<Navigate to="dashboard" replace />} />
        </Routes>
      </div>
    </div>
  );
};

export default Admin;