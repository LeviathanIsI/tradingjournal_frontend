// src/hooks/useOptionTrades.js
import { useState, useEffect } from "react";
import { fetchStats } from "../utils/fetchStats";

export const useOptionTrades = () => {
  const [trades, setTrades] = useState([]);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchTrades = async () => {
    try {
      const token = localStorage.getItem("token");
      if (!token) {
        throw new Error("No authentication token found");
      }

      const response = await fetch(
        `${import.meta.env.VITE_API_URL}/api/option-trades`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        }
      );

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Failed to fetch option trades");
      }

      const data = await response.json();
      setTrades(data.data);
      setError(null);
    } catch (err) {
      console.error("Error fetching option trades:", err);
      setError(err.message);
    }
  };

  const fetchOptionTradeStats = async () => {
    try {
      const statsData = await fetchStats("option-trades");
      console.log("📊 Option Trade Stats API Response:", statsData);
      return statsData || { totalProfit: 0, totalTrades: 0 };
    } catch (error) {
      console.error("❌ Error fetching option trade stats:", error);
      return { totalProfit: 0, totalTrades: 0 };
    }
  };

  useEffect(() => {
    const loadData = async () => {
      try {
        setLoading(true);
        await Promise.all([fetchTrades(), fetchOptionTradeStats()]);
      } catch (err) {
        console.error("Error loading initial data:", err);
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, []);

  const deleteOptionTrade = async (tradeId) => {
    try {
      const token = localStorage.getItem("token");
      if (!token) throw new Error("No authentication token found");

      const response = await fetch(
        `${import.meta.env.VITE_API_URL}/api/option-trades/${tradeId}`,
        {
          method: "DELETE",
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        }
      );

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Failed to delete option trade");
      }

      await fetchTrades();
      return true;
    } catch (err) {
      console.error("Error deleting option trade:", err);
      return false;
    }
  };

  return {
    trades,
    stats,
    loading,
    error,
    fetchTrades,
    fetchOptionTradeStats,
    deleteOptionTrade,
  };
};
