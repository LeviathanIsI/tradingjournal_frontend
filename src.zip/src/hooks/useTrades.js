import { useState, useEffect } from "react";
import { fetchStats } from "../utils/fetchStats";

export const useTrades = (user) => {
  const [trades, setTrades] = useState([]);
  const [stats, setStats] = useState({ totalProfit: 0, totalTrades: 0 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [hasFetched, setHasFetched] = useState(false); // ✅ Track if fetch has already run

  useEffect(() => {
    if (!user || hasFetched) return; // ✅ Stop duplicate fetches

    console.log("📥 Fetching trade data...");

    const loadData = async () => {
      try {
        setLoading(true);
        await Promise.all([fetchTrades(), fetchTradeStats()]);
        setHasFetched(true); // ✅ Mark fetch as done
        console.log("✅ Trade data loaded.");
      } catch (err) {
        console.error("❌ Error loading trade data:", err);
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, [user]); // ✅ Only runs when `user` is first set

  return {
    trades,
    stats,
    loading,
    error,
    fetchTrades,
    fetchTradeStats,
  };
};
